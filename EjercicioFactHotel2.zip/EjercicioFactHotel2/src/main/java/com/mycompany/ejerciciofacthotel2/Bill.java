/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class Bill extends Huesped{
    public int billNo;
        
    public Bill(){
    }

    public Bill(int billNo, String guestName, int tipoId, String id, int cc) {
        this.billNo = billNo;
        super.guestName = guestName;
        super.tipoId = tipoId;
        super.id = id;
        super.cc = cc;
    }

    public int getBillNo() {
        return billNo;
    }

    public void setBillNo(int billNo) {
        this.billNo = billNo;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }
    
    @Override
    public String toString() {
        if (id != null){
        return "Factura nro " + billNo + " para el cliente " + guestName + " con identificacion " + id ;
        } 
        else {
        return "Factura nro " + billNo + " para el cliente " + guestName + " con identificacion " + cc ;
        }
    }
    
    
}

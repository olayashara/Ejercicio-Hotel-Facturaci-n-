/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
import java.util.ArrayList;
import java.util.List;

public class Incidentes {
    private List<Incidente> incidentes;

    public Incidentes() {
        this.incidentes = new ArrayList<>();
    }

    public void agregarIncidente(int tipo, double costo) {
        Incidente incidente = new Incidente(tipo, costo);
        incidentes.add(incidente);
    }

    public double calcularCostoTotalIncidentes() {
        double total = 0;
        for (Incidente incidente : incidentes) {
            total += incidente.getCosto();
        }
        return total;
    }

    private class Incidente {
        private int tipo;
        private double costo;

        public Incidente(int tipo, double costo) {
            this.tipo = tipo;
            this.costo = costo;
        }

        public double getCosto() {
            return costo;
        }
    }
}
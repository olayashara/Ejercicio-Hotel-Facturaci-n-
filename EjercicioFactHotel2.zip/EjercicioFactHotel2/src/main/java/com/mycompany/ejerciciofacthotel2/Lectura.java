/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
import java.util.Scanner;

public class Lectura {
    Scanner sc = new Scanner(System.in);
        public String leerString(String mensaje){
        System.out.println(mensaje);
        String dato = sc.nextLine();
        return dato;
    }
    public int leeryValidarInt(String mensaje) {
        int dato;
        do {
            System.out.print(mensaje);
            while (!sc.hasNextInt()) {
                System.out.println("Valor no válido");
                sc.next();
                System.out.println("Debe ser número entero positivo. Intente nuevamente: ");
            }
            dato = sc.nextInt();
            if(dato < 0){
                System.out.println("El número debe ser positivo");
            }
        } while (dato < 0);
        return dato;
    }
    
    public int leeryValidarInt2(String mensaje, int min, int max) {
    int dato;
    do {
        System.out.print(mensaje);
        while (!sc.hasNextInt()) {
            System.out.println("Valor no válido. Intente nuevamente: ");
            sc.next(); // Descarta la entrada no válida
        }
        dato = sc.nextInt();
        if (dato < min || dato > max) {
            System.out.println("Por favor, ingrese un número entre " + min + " y " + max + ".");
        }
    } while (dato < min || dato > max); // Valida que el dato esté dentro del rango permitido
    return dato;
}
    
    public char leerChar(String mensaje) {
        System.out.print(mensaje);
        char caracter = sc.next().charAt(0); // Lee el primer carácter de la entrada del usuario
        sc.nextLine(); // Consumir el salto de línea pendiente después de la entrada del usuario
        return caracter;
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class Facturación {
    Lectura lectura = new Lectura();
    static int tipoId;
    static String id;
    static int cc;
    static int preguntar;
    
    Room habitacion = new Room(); // Inicialmente, daños es 0
    Bill factura = new Bill();      
    Robos robos = new Robos();
    Incidentes incidentes = new Incidentes();
    Lavanderia lavanderia1 = new Lavanderia();
    
    

    public void recopilacionDatos() {
        // Solicita los datos del cliente y de la habitación
        factura.setBillNo((int) (Math.random() * 100000));
        factura.setGuestName(lectura.leerString("Nombre completo del cliente: "));
        factura.setTipoId(lectura.leeryValidarInt2("Ingrese 1 si es CC, 2 si es CE, 3 si es PAS: ",1,3));
        tipoId = factura.getTipoId();
        valTipo();
        habitacion.setNroHabitación(lectura.leeryValidarInt2("Ingrese el número de la habitación: ", 100, 499));
//        habitacion.setLocation(lectura.leeryValidarInt("Ingrese 1 si es individual, 2 si es doble, 3 si es familiar, 4 si es suite "));
        habitacion.setTiempo(lectura.leeryValidarInt("Ingrese el tiempo de estadía en noches: "));
        incidentes();
        int precio = calcularPrecioRoom();
        habitacion.setPrecio(precio*habitacion.getTiempo());
        preguntar = lectura.leeryValidarInt("ingrese (1) si lavó, (2) si no lavó: ");
        cobrarLavanderia();
         
}
    public void incidentes(){
        char respuestaRobos = lectura.leerChar("¿Hubo robos durante la estancia? (s/n): ");
        if (respuestaRobos == 's' || respuestaRobos == 'S') {
            int costoRobos = lectura.leeryValidarInt("Ingrese el costo de los robos: ");
            robos.registrarRobos(true, costoRobos);
        }
          
        agregarIncidentes(incidentes); // Método para agregar incidentes 
    }
    
    public void cobrarLavanderia(){
        if(lavar()){
            lavanderia1.setNumeroLavadas(lectura.leeryValidarInt("Ingrese el numero de veces que uso el servicio: "));
            lavanderia1.setTotalLavanderia(lavanderia1.getNumeroLavadas() * lavanderia1.getPrecioServicio());
        }
        
    }
    
    public static boolean lavar(){
        if(preguntar == 1){
            return true;
        }
        else{
            return false;
        }
    }
    public void valTipo(){
        if (tipoId == 1){
           cc = lectura.leeryValidarInt("Ingrese su número de documento: ");
           factura.setCc(cc);
            
        }
        else {
           id = lectura.leerString("Ingrese su número de documento: ");
           factura.setId(id);
           
        }
    }
    
   private void agregarIncidentes(Incidentes incidentes) {
    int tipoIncidente;
    int calcularMas = 1;
    do {
        tipoIncidente = lectura.leeryValidarInt2("Ingrese el tipo de incidente (1 para daño leve, 2 para daño moderado, 3 para daño severo, 4 si no hay daños): ", 1, 4);
        int costoIncidente = 0;
        switch (tipoIncidente) {
            case 1 -> costoIncidente = 30000; // Daño leve
            case 2 -> costoIncidente = 40000; // Daño moderado
            case 3 -> costoIncidente = 60000; // Daño severo
            case 4 -> System.out.println("No se registraron daños.");
            default -> {
            }
        }
        
        if (tipoIncidente >= 1 && tipoIncidente <= 3) {
            incidentes.agregarIncidente(tipoIncidente, costoIncidente);
            System.out.println("Daño registrado con éxito.");
        }

        // Verifica si el usuario quiere agregar más incidentes solo si no ha elegido la opción "no hay daños"
        if (tipoIncidente != 4) {
            calcularMas = lectura.leeryValidarInt2("¿Desea registrar otro incidente? (0) para No, (1) para Sí): ", 0, 1);
        } else {
            calcularMas = 0; // No preguntar de nuevo si elige la opción de no hay daños
        }
    } while (calcularMas == 1);
}

    private int calcularPrecioRoom(){
        int s1 = (habitacion.getNroHabitación() / 100);
        return switch (s1) {
            case 1 -> 150000; // habitación individual
            case 2 -> 230000; // habitación doble
            case 3 -> 340000; // habitación familiar
            case 4 -> 500000; // habitación suite
            default -> 0;
        };
    }
    
    public void incidentesyRobos(){
        if (incidentes.calcularCostoTotalIncidentes() != 0){
            imprimir("Valor a pagar por incidentes ocasionados: " + incidentes.calcularCostoTotalIncidentes());
        }
        if (robos.getCostoRobos() != 0){
            imprimir("Valor a pagar por robos: " + robos.getCostoRobos());
        }
    }
    
    public void imprimirFactura(){     
        double costoTotal = habitacion.getPrecio()+lavanderia1.getTotalLavanderia() 
                + incidentes.calcularCostoTotalIncidentes() + robos.getCostoRobos();
        imprimir(factura.toString());
        imprimir(habitacion.toString());
        imprimir(lavanderia1.toString());
        incidentesyRobos();
        
        imprimir("Costo total a pagar: "+ costoTotal);
    }
    
    private void imprimir(String cadena){
        System.out.println(cadena);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class Room {
    public int nroHabitación;
    public int location;
    public int precio;
    public int tiempo;
    public int daños;
    
    public Room() {
    }

    public Room(int nroHabitación,int location, int precio, int tiempo, int daños) {
        this.nroHabitación = nroHabitación;
        this.location = location;
        this.precio = precio;
        this.tiempo = tiempo;
        this.daños = daños;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    public int getNroHabitación() {
        return nroHabitación;
    }

    public int getDaños() {
        return daños;
    }

    public void setDaños(int daños) {
        this.daños = daños;
    }

    public void setNroHabitación(int nroHabitación) {
        this.nroHabitación = nroHabitación;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }
@Override
    public String toString() {
        return "Habitación nro: " + nroHabitación +" \n con tarifa por noche de: " + precio + " pesos \n ocupada en un tiempo de: " + tiempo + " noche(s)";
    }
    
}
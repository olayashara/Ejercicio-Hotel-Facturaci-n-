/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class Huesped {
    public String guestName;
    public int tipoId;
    public String id;
    public int cc;

    public Huesped() {
    }

    public Huesped(String nombre, int tipoId, String id, int cc) {
        this.guestName = nombre;
        this.tipoId = tipoId;
        this.id = id;
        this.cc = cc;
    }

    public String getNombre() {
        return guestName;
    }

    public void setNombre(String nombre) {
        this.guestName = nombre;
    }

    public int getTipoId() {
        return tipoId;
    }

    public void setTipoId(int tipoId) {
        this.tipoId = tipoId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }
    

}
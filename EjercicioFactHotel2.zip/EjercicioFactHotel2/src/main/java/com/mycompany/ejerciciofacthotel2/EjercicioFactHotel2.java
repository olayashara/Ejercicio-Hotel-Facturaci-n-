/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class EjercicioFactHotel2 {

    public static void main(String[] args) {
        Facturación Fact = new Facturación();
        Fact.recopilacionDatos();
        Fact.imprimirFactura();
    }
}

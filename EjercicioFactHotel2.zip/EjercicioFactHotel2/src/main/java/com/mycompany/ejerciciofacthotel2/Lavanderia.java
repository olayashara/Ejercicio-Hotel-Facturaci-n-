/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class Lavanderia { 
    public int preguntar;
    public int totalLavanderia;
    public int precioServicio = 50000;
    public int numeroLavadas;
    
   
    public Lavanderia() {
    }

    public Lavanderia(int preguntar, int totalLavanderia) {
        this.preguntar = preguntar;
        this.totalLavanderia = totalLavanderia;
    }
 public int getPrecioServicio() {
        return precioServicio;
    }

    public void setPrecioServicio(int precioServicio) {
        this.precioServicio = precioServicio;
    }

    public int getNumeroLavadas() {
        return numeroLavadas;
    }

    public void setNumeroLavadas(int numeroLavadas) {
        this.numeroLavadas = numeroLavadas;
    }
    public int getPreguntar() {
        return preguntar;
    }

    public void setPreguntar(int preguntar) {
        this.preguntar = preguntar;
    }

    public int getTotalLavanderia() {
        return totalLavanderia;
    }

    public void setTotalLavanderia(int totalLavanderia) {
        this.totalLavanderia = totalLavanderia;
    }

    @Override
    public String toString() {
        return "Costo total de lavandería: " + totalLavanderia + ", con precio por servicio de " + precioServicio + " y un numero de lavadas " + numeroLavadas;
    }
    
    
}
